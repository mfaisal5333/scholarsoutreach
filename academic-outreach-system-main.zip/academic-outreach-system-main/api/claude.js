// Vercel serverless function: proxies Claude API calls so the API key stays
// server-side. The browser POSTs { prompt, jsonMode, model } to /api/claude
// and we forward to Anthropic with the CLAUDE_API_KEY env var.
//
// Setup (one-time):
//   1. Get a key at https://console.anthropic.com/settings/keys
//   2. In Vercel project settings -> Environment Variables, add:
//        Name:  CLAUDE_API_KEY
//        Value: sk-ant-...your-key...
//        Environments: Production, Preview, Development
//   3. Redeploy. The browser never sees the key.

export default async function handler(req, res) {
  // CORS for browser fetches (same-origin should work without these, but harmless)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const apiKey = process.env.CLAUDE_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "Server missing CLAUDE_API_KEY env var. Add it in Vercel project settings." });
  }

  // Vercel parses JSON body automatically when content-type is application/json.
  // For safety, also handle the case where it arrives as a string.
  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { return res.status(400).json({ error: "Invalid JSON body" }); }
  }
  if (!body || typeof body !== "object") {
    return res.status(400).json({ error: "Missing JSON body" });
  }

  const { prompt, model, jsonMode } = body;
  if (!prompt || typeof prompt !== "string") {
    return res.status(400).json({ error: "Missing 'prompt' string in body" });
  }

  // Whitelist allowed models so callers can't burn through expensive tokens.
  const allowed = new Set([
    "claude-haiku-4-5-20251001",
    "claude-sonnet-4-6",
    "claude-opus-4-6"
  ]);
  const useModel = allowed.has(model) ? model : "claude-haiku-4-5-20251001";

  try {
    const claudeRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model: useModel,
        max_tokens: 1024,
        temperature: jsonMode ? 0.3 : 0.4,
        messages: [{ role: "user", content: prompt }]
      })
    });

    if (!claudeRes.ok) {
      const errText = await claudeRes.text();
      return res.status(claudeRes.status).json({ error: errText.slice(0, 500) });
    }

    const data = await claudeRes.json();
    const text = data && data.content && data.content[0] && data.content[0].text;
    if (!text) return res.status(500).json({ error: "Empty Claude response" });

    return res.status(200).json({ text });
  } catch (err) {
    return res.status(500).json({ error: String(err && err.message || err) });
  }
}
