// Vercel serverless function: Upstash Redis store for cross-device data persistence.
// Authenticates via Google ID token, stores per-user data in Upstash Redis.
//
// Setup:
//   1. In Vercel Dashboard → Storage → Create Upstash Redis Database
//   2. Connect it to this project (prefix: UPSTASH_REDIS_REST)
//   3. Redeploy.

import { Redis } from "@upstash/redis";

const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_KV_REST_API_URL,
  token: process.env.UPSTASH_REDIS_REST_KV_REST_API_TOKEN
});

const ALLOWED_KEYS = new Set(["state", "europass", "emailLog", "professors", "profStatus", "sentEmails"]);
const TTL_SECONDS = 90 * 24 * 60 * 60; // 90 days

// Verify Google ID token and extract sub claim
async function verifyGoogleToken(token) {
  if (!token) return null;
  const res = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(token));
  if (!res.ok) return null;
  const info = await res.json();
  if (!info.sub) return null;
  return info.sub;
}

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  // Extract token from Authorization header
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token) return res.status(401).json({ error: "Missing authorization token" });

  // Verify token
  const sub = await verifyGoogleToken(token);
  if (!sub) return res.status(401).json({ error: "Invalid or expired token" });

  // Parse body
  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { return res.status(400).json({ error: "Invalid JSON body" }); }
  }
  if (!body || typeof body !== "object") {
    return res.status(400).json({ error: "Missing JSON body" });
  }

  const { action, key, value } = body;

  try {
    if (action === "save") {
      if (!key || !ALLOWED_KEYS.has(key)) {
        return res.status(400).json({ error: "Invalid key. Allowed: " + [...ALLOWED_KEYS].join(", ") });
      }
      const kvKey = `pm:${sub}:${key}`;
      await redis.set(kvKey, value, { ex: TTL_SECONDS });
      return res.status(200).json({ ok: true });

    } else if (action === "load") {
      if (!key || !ALLOWED_KEYS.has(key)) {
        return res.status(400).json({ error: "Invalid key. Allowed: " + [...ALLOWED_KEYS].join(", ") });
      }
      const kvKey = `pm:${sub}:${key}`;
      const data = await redis.get(kvKey);
      return res.status(200).json({ data: data !== null ? data : null });

    } else if (action === "load-all") {
      const keys = [...ALLOWED_KEYS].map(k => `pm:${sub}:${k}`);
      const pipeline = redis.pipeline();
      for (const k of keys) pipeline.get(k);
      const results = await pipeline.exec();
      const out = {};
      const keyArr = [...ALLOWED_KEYS];
      for (let i = 0; i < keyArr.length; i++) {
        out[keyArr[i]] = results[i] !== null ? results[i] : null;
      }
      return res.status(200).json({ data: out });

    } else {
      return res.status(400).json({ error: "Invalid action. Use: save, load, load-all" });
    }
  } catch (err) {
    console.error("KV error:", err);
    return res.status(500).json({ error: "Storage error: " + String(err && err.message || err) });
  }
}
